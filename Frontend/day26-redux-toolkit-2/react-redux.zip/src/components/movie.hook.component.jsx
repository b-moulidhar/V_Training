import { useDispatch, useSelector } from "react-redux";
import { addMovie, delMovie } from "../redux";

let MovieHookComp = (props)=>{

    const Movies = useSelector(state=> state.Movies.nMovies)
    let dispatch = useDispatch()
    return <div>
    <h2>Movies Hook</h2>
    <h3>total Movies : {Movies}</h3>
    <button onClick={()=>{dispatch(addMovie())}}>add hero</button>
    <button onClick={()=>{dispatch(delMovie())}}>remove hero</button>
</div>
}
export default MovieHookComp;