import { Component } from "react";
import { connect } from "react-redux";
import { addHero, delHero } from "../redux";

class HeroComp extends Component{
    render(){
        return <div>
            <h2>Heroes</h2>
            <h3>total heroes : {this.props.nHeroes}</h3>
            <button onClick={this.props.addHero}>add hero</button>
            <button onClick={this.props.delHero}>remove hero</button>
        </div>
    }
}
let mapStateToProps=(state)=>{
    return{
        nHeroes: state.Heroes.nHeroes
    }
}

let mapDispatchToProps = (dispatch)=>{
    return{
        addHero : ()=>{ dispatch( addHero()) },
        delHero : ()=>{ dispatch(delHero()) }
    }
}

export default connect(mapStateToProps,mapDispatchToProps)(HeroComp);