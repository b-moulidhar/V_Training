import { useDispatch, useSelector } from "react-redux";
import { addHero, delHero } from "../redux";

let HeroHookComp = (props)=>{

    const heroesss = useSelector(state=> state.Heroes.nHeroes)
    let dispatch = useDispatch()
    return <div>
    <h2>Heroes Hook</h2>
    <h3>total heroes : {heroesss}</h3>
    <button onClick={()=>{dispatch(addHero())}}>add hero</button>
    <button onClick={()=>{dispatch(delHero())}}>remove hero</button>
</div>
}
export default HeroHookComp;