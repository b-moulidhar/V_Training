import { Component } from "react";
import { connect } from "react-redux";
import { addMovie,  delMovie, setMovie } from "../redux";

class MovieComp extends Component{
    render(){
        return <div>
            <h2>Movies</h2>
            <h3>total Movies : {this.props.nMovies}</h3>
            <button onClick={this.props.addMovie}>add hero</button>
            <button onClick={this.props.delMovie}>remove hero</button>
        </div>
    }
}
let mapStateToProps=(state)=>{
    return{
        nMovies:state.Movies.nMovies
    }
}

let mapDispatchToProps = (dispatch)=>{
    return{
        addMovie : ()=>{ dispatch( addMovie()) },
        delMovie : ()=>{ dispatch(delMovie()) },
        setMovie : ()=>{dispatch(setMovie())}
    }
}

export default connect(mapStateToProps,mapDispatchToProps)(MovieComp);