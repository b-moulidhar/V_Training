import { Component } from "react";
import HeroComp from "./components/hero.component";
import HeroHookComp from "./components/hero.hook.component";
import MovieComp from "./components/movie.component";
import MovieHookComp from "./components/movie.hook.component";

class App extends Component{
    render(){
        return <div>
            <h1>Welcome to universe 7</h1>
            <hr />
            <h2><HeroComp/></h2>
            <h2><HeroHookComp/></h2>
            <hr />
            <h2><MovieComp/></h2>
            <h2><MovieHookComp/></h2>
        </div>
    }
}
export default App;