// import { addHero, delHero } from "./hero.action.creators";
import { ADD_MOVIE, REMOVE_MOVIE, SET_MOVIE} from "./movie.types";

const initialState = {
    nMovies : 0
}

const MovieReducer = (state = initialState,action)=>{
    switch(action.type){
        case ADD_MOVIE : return {...state, nMovies: state.nMovies+1}
        case REMOVE_MOVIE : return {...state, nMovies: state.nMovies-1}
        case SET_MOVIE : return {...state, nMovies: action.payload}
        default : return state
    }
}

export {MovieReducer};