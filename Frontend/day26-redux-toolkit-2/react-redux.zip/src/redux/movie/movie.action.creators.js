import { ADD_MOVIE,REMOVE_MOVIE, SET_MOVIE } from "./movie.types";

let addMovie = ()=>{
    return{
        type : ADD_MOVIE
    }
}
let delMovie = ()=>{
    return{
        type : REMOVE_MOVIE
    }
}
let setMovie = (potato)=>{
    return{
        type : SET_MOVIE,
        payload : potato
    }
}

export { addMovie , delMovie, setMovie }