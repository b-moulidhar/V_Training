import {legacy_createStore as createStore, combineReducers} from "redux";
import { heroReducer } from "./hero/hero.reducers";
import { MovieReducer } from "./movie/movie.reducers";

let rootReducer = combineReducers({
    Heroes : heroReducer,
    Movies : MovieReducer
})

const store = createStore(rootReducer);

export default store