import { ADD_HERO,REMOVE_HERO } from "./hero.types";

let addHero = ()=>{
    return{
        type : ADD_HERO
    }
}
let delHero = ()=>{
    return{
        type : REMOVE_HERO
    }
}
let setHero = (potato)=>{
    return{
        type : REMOVE_HERO,
        payload : potato
    }
}

export { addHero , delHero, setHero }