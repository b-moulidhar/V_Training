// import { addHero, delHero } from "./hero.action.creators";
import { ADD_HERO, REMOVE_HERO, SET_HERO} from "./hero.types";

const initialState = {
    nHeroes : 0
}

const heroReducer = (state = initialState,action)=>{
    switch(action.type){
        case ADD_HERO : return {...state, nHeroes:state.nHeroes+1}
        case REMOVE_HERO : return {...state, nHeroes:state.nHeroes-1}
        case SET_HERO : return {...state, nHeroes:action.payload}
        default : return state
    }
}

export {heroReducer};