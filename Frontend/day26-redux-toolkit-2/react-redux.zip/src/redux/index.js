// import { addHero, delHero } from "./hero/hero.action.creators";
// export {delHero,addHero};

export { delHero,addHero ,setHero} from "./hero/hero.action.creators";
export { delMovie, addMovie, setMovie } from "./movie/movie.action.creators";