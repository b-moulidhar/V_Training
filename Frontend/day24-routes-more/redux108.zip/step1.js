const redux = require("redux");
let createStore = redux.legacy_createStore;
//action type is a constant name
//action creator creator is function that returns an sction object
//reducer is a function which has switch cases to all functions based on action type
//initial state is initial value of store object
//store is an object that stores all share states of your application
//subscribe / unsubscribe to lixten to changes of store
//dispatch is a method that can take action object

//ACTION
const ADDHERO ="Addhero";

//ACTION CREATOR
let addHero =()=>{
    return {
        type : ADDHERO
    }
}
//INITIAL STATE
let initialState = {
    numofheroes :0
}


let reducer = (state = initialState,action)=>{
    switch(action.type){
        case ADDHERO : return {numofheroes:state.numofheroes+1};
        default : return state;
    }
};

let store = createStore(reducer);

let unsubscibe = store.subscribe(()=>{console.log("subscribed",store.getState())});

store.dispatch( addHero());
store.dispatch( addHero());
store.dispatch( addHero());
unsubscibe();
console.log("unsubscribed")
store.dispatch( addHero());
store.dispatch( addHero());
console.log(store.getState());



