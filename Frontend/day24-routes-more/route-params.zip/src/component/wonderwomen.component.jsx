import { useParams } from "react-router-dom"
let WonderWomenComp =()=>{
    let prms = useParams()
    return <div>
        <h1>WonderWomen
         Component</h1>
        <h2> quantity :{prms.qty}</h2>
    </div>
}
export default WonderWomenComp;