import {Outlet} from "react-router-dom"
import {BrowserRouter,Routes,Route,NavLink} from "react-router-dom"
import React from "react";
import { Suspense } from "react";
// import Batmovie1Comp from "./component/batmovie1.component";
// import Batmovie2Comp from "./component/batmovie2.component";
// import Batmovie3Comp from "./component/batmovie3.component";
let BatmanComp =()=>{
    return <div>
        <h1>Batman Component</h1>
        {/* <BrowserRouter>
            <Routes>
                    <Route path="batman/movie1" element={<Suspense><Batmovie1Comp/> </Suspense> }></Route>
                    <Route path="batman/movie2" element={<Suspense fallback={<> loading...</>}><Batmovie2Comp/> </Suspense> }></Route>
                    <Route path="batman/movie3" element={<Suspense fallback={<> loading...</>}> <Batmovie3Comp/></Suspense> }></Route>
            </Routes>
        </BrowserRouter> */}
        
        <Outlet/>
    </div>
}
export default BatmanComp;