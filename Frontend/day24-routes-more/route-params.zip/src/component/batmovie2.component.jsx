let Batmovie2Comp =()=>{
    return <div>
        <h1>Batmovie2Comp Component</h1>
    </div>
}
export default Batmovie2Comp;