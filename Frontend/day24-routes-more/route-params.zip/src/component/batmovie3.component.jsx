let Batmovie3Comp =()=>{
    return <div>
        <h1>Batmovie3Comp Component</h1>
    </div>
}
export default Batmovie3Comp;