let Batmovie1Comp =()=>{
    return <div>
        <h1>Batmovie1Comp Component</h1>
    </div>
}
export default Batmovie1Comp;