import { useNavigate } from "react-router-dom";

let SupermanComp =()=>{
        let navBat = useNavigate();
        let wonderNav = useNavigate();
    return <div>
        <h1>Superman Component</h1>
        <button onClick={()=>{navBat("/batman",{replace:true})}}>batman </button>
        <button onClick={()=>{wonderNav("/wonderwoman/"+30,{replace:true})}}>wonderwoman with quantity</button>
    </div>
}
export default SupermanComp;