import React,{ useState}  from "react";
import { Suspense } from "react";
import {BrowserRouter,Routes,Route,NavLink} from "react-router-dom"

// import AquamanComp from "./component/aquaman.component";
// import BatmanComp from "./component/batman.component";
import HomeComp from "./component/home.component";
import "./myroute.css"
// import NotFoundComp from "./component/notfound.component";
// import SupermanComp from "./component/superman.component";
// import WonderWomenComp from "./component/wonderwomen.component";
let AquamanComp = React.lazy(()=> import('./component/aquaman.component'));
let BatmanComp = React.lazy(()=>import('./component/batman.component'));
let SupermanComp = React.lazy(()=>import('./component/superman.component'));
let WonderWomenComp = React.lazy(()=>import('./component/wonderwomen.component'));
let NotFoundComp = React.lazy(()=>import('./component/notfound.component'));
let Batmovie1Comp = React.lazy(()=> import('./component/batmovie1.component'));
let Batmovie2Comp = React.lazy(()=> import('./component/batmovie2.component'));
let Batmovie3Comp = React.lazy(()=> import('./component/batmovie3.component'));


let App =()=>{
    let [quantity,setQuantity] = useState(0);
    let activeFun1 = ({isActive})=> isActive ? 'box' : 'plainBox';
    let activeFun2 = ({isActive})=> {
      return {
        width: "200px",
        display: "inline-block",
        backgroundColor: isActive ? "crimson" : "darkorange",
        color:  "papayawhip",
        textAlign: "center",
        padding: "5px",
      }
    };
    return <div>
        <h1>Universe Heroes Component</h1>
        <BrowserRouter>
        <ul>
            <label htmlFor="">
               set quantity for wonderwoman <input value={quantity} type="number" onChange={(evt)=>{ setQuantity(evt.target.value) }} /> <h2>{quantity}</h2>
            </label>
            <li><NavLink end className={activeFun1} to="/">Home Component</NavLink></li>
            <li><NavLink style={ activeFun2 } to="/batman">Batman Component</NavLink></li>
            <li><NavLink className={({isActive})=> isActive ? 'box':''} to="/" end>Home</NavLink></li>
            <li><NavLink className={({isActive})=> isActive ? 'box':''} to="batman">batman</NavLink></li>
            <li><NavLink className={({isActive})=> isActive ? 'box':''} to="/batman/movie1">batman movie 1</NavLink></li>
            <li><NavLink className={({isActive})=> isActive ? 'box':''} to="/batman/movie2">batman movie 2</NavLink></li>
            <li><NavLink className={({isActive})=> isActive ? 'box':''} to="/batman/movie3">batman movie 3</NavLink></li>
            <li><NavLink className={({isActive})=> isActive ? 'box':''} to="superman">superman</NavLink></li>
            <li><NavLink className={({isActive})=> isActive ? 'box':''} to="aquaman">aquaman</NavLink></li>
            <li><NavLink className={({isActive})=> isActive ? 'box':''} to="wonderwoman">wonderwoman</NavLink></li>
            <li><NavLink className={({isActive})=> isActive ? 'box':''} to={"/wonderwoman/"+quantity}>wonderwoman with params</NavLink></li>
            <li><NavLink className={({isActive})=> isActive ? 'box':''} to="flash">flash</NavLink></li>
            <li><NavLink className={({isActive})=> isActive ? 'box':''} to="cyborg">cyborg</NavLink></li>
            {/* <li><Link to="/">Home</Link></li>
            <li><Link to="batman">batman</Link></li>
            <li><Link to="superman">superman</Link></li>
            <li><Link to="aquaman">aquaman</Link></li>
            <li><Link to="wonderwoman">wonderwoman</Link></li>
            <li><Link to="flash">flash</Link></li>
            <li><Link to="cyborg">cyborg</Link></li> */}
        </ul>
        
        
            <Routes>
                <Route path="" element={<Suspense fallback={<> loading...</>}><HomeComp/> </Suspense> }/>
                <Route path="batman" element={<Suspense fallback={<> loading...</>}><BatmanComp/> </Suspense>}>
                    <Route path="/batman/movie1" element={<Suspense fallback={<> loading...</>}> <Batmovie1Comp/> </Suspense> }></Route>
                    <Route path="/batman/movie2" element={<Suspense fallback={<> loading...</>}><Batmovie2Comp/> </Suspense> }></Route>
                    <Route path="/batman/movie3" element={<Suspense fallback={<> loading...</>}> <Batmovie3Comp/></Suspense> }></Route>
                </Route>
                <Route path="aquaman" element={<Suspense fallback={<> loading...</>}><AquamanComp/> </Suspense> }/>
                <Route path="superman" element={<Suspense fallback={<> loading...</>}><SupermanComp/> </Suspense> }/>
                <Route path="wonderwoman" element={<Suspense fallback={<> loading...</>}> <WonderWomenComp/></Suspense> }/>
                <Route path="wonderwoman/:qty" element={<Suspense fallback={<> loading...</>}> <WonderWomenComp/></Suspense> }/>
                <Route path="flash" element={<Suspense fallback={<> loading...</>}> <SupermanComp/></Suspense> }/>
                <Route path="*" element={<Suspense fallback={<> loading...</>}><NotFoundComp/></Suspense>  }/>
            </Routes>
        </BrowserRouter>
    </div>
}
export default App;