import { useEffect } from "react"
import axios from "axios";
import { useState } from "react";
import "./mystyle.css"
 
let HomeComp = ()=>{
    let [hero, setHeroes] = useState([]);
    // let [nhero, createHero] = useState({ title : '', firstname : '', lastname : ''});
    // let [ehero, modifyHero] = useState({ _id:'', title : '', firstname : '', lastname : ''});
    // let [toggle, toggleHandler] = useState(false);
    let [carthero, modifyCart] = useState({ _id:'', hero : '', name : '', price : 0 , instock:true });
    let [qty, updateQty] = useState(0);
    let [temp, addData] = useState([]);
 
    let refresh = ()=>{
        axios.get("http://localhost:8080/data").then(res => {
            setHeroes(res.data);
        })
    }
 
    useEffect(function(){
       refresh();
    },[]);

    let clickHandler=(evt)=>{
        updateQty({ quantity:Number(evt.target.value)})
    }

    let AddCart=(hid)=>{
        axios.get("http://localhost:8080/gdata/"+hid).then(res => {
            
            modifyCart(res.data)
            temp.push(res.data.hero);
            temp.push(res.data.quantity);
            temp.push(res.data.price);
            console.log(temp)   ;
        })
            .catch((err)=>{

                console.log("Error",err);
            })
          
    }
    return <div>
                
            <div id="ubox">
                <h1>Avengers Store</h1>
                {
                        hero.map((hero, idx) =>{
                            
                            return <div key={hero._id} className="box">
                                Title : {hero.hero} <br />
                                price : {hero.price} <br />
                                instock:{hero.instock}
                                Quantity <br />
                                <input min={0} onBlur={(evt)=>{clickHandler(evt)}} type="number" /> &nbsp; &nbsp; 
                                <button onClick={()=>{AddCart(hero._id)}}>Add to cart</button>
                                {/* {console.log(hero._id)} */}
                            </div>
                        })
                    }
                        </div>
                    <div>
                        <div id="cart">
                            <h1>cart</h1>
                            
                            <h3>Name:{carthero.hero} &nbsp; Quantity:{qty.quantity} &nbsp; price :{carthero.price*Number(qty.quantity)}</h3> <br />
                            <hr />
                            <h2>Total:{carthero.price*Number(qty.quantity)}</h2>
                        <button>buy now</button>
                   </div>
                    </div>
                       
                    
                
            </div>
}
 
export default HomeComp; 
 
 
// http://p.ip.fi/-sGR