import "./mystyle1.css"
import { useEffect } from "react"
import { useState } from "react"
import axios from "axios"

let OutputComp = ()=>{
    let[users,setUser] = useState([])
    // let [ncart, updateCart] = useState({ name : '', qty : '', price : ''});
    let refresh = ()=>{
        axios.get("http://localhost:8080/data").then(res => {
            setUser(res.data);
        })
    }
    let editCart = (hid)=>{

    }
    useEffect(()=>{
        refresh()
    },[])
    return <div>
                {
                users.map((val,idx)=>{
                    return  <div key={val._id} className="cont">
                                <p>TITLE : {val.hero}</p>
                                <p>NAME: {val.name}</p>
                                <p>PRICE: {val.price}</p>
                                <form action="#">
                                <label  id="qty">QUANTIY <br />
                                    <input type="number" className="qty" min="0" required/>
                                </label>
                                <input type="submit" onClick={()=> editCart(val._id)} className="btn btn-warning" value="ADD TO CART"/>
                                </form>
                               
                            </div>
                })
                }
                <div className="cart">
                    <p style={{textAlign:"center"}}>Cart</p>
                    <hr />
                </div>
          
        </div>
   
}
export default OutputComp