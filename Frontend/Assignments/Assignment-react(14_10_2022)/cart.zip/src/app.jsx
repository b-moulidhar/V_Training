import HomeComp from "./component/home.component";
import OutputComp from "./component/output.component";

let App =()=>{
    return <div>
        {/* <h1>Avengers store</h1> */}
        <HomeComp/>
        {/* <OutputComp/> */}
    </div>
}
export default App;