import PopUp from "./component/popup.component";
import { Component } from "react";


class App extends Component{
    state={
        title : "App component",
        show : false
    }
    toggleFun = ()=>{
        this.setState({
            show : !this.state.show
        })
    }
    changeTitle =()=>{
        this.setState({
            title:"title changed in popup"
        })
    }
    render(){
        return <div>
                <h1>{this.state.title}</h1>
                {this.state.show ? <PopUp>
                <div>
                    <h2>popup</h2>
                    <p>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Assumenda veniam quibusdam ipsa aspernatur soluta enim laudantium iure aut dolore explicabo, harum corrupti esse eum dolor odit ea ullam quam amet.
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi temporibus dicta quas? Quibusdam unde amet eligendi cupiditate, fuga tenetur facere ut asperiores id qui impedit ea suscipit sunt deserunt ipsum!
                        Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quod, quidem tenetur exercitationem doloremque sit nisi quo sed aspernatur modi beatae earum! Cupiditate unde hic obcaecati eveniet labore laudantium eum minima?
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Quo, illum voluptas! At dolor, odit fugit ut tempora adipisci aperiam rem iste ipsa totam, aut nihil ea libero saepe vel blanditiis?
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Porro reiciendis eligendi exercitationem sequi vel harum ullam dignissimos doloribus et saepe provident esse, quaerat impedit reprehenderit ab fugiat quae cupiditate temporibus?
                    </p>
                    <button onClick={this.toggleFun}>hide popup</button>
                    <button onClick={this.changeTitle}>change title</button>
                </div>
                </PopUp>: <button onClick={this.toggleFun}>show popup</button>}
        </div>
    }
}
export default App;