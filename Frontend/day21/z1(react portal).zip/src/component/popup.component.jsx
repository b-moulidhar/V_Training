import  ReactDOM  from "react-dom";
const { Component } = require("react");

class PopUp extends Component{
    render(){
        return ReactDOM.createPortal(this.props.children,document.getElementById("popup"));
    }
}
export default PopUp;