import { Component } from "react";
import axios from "axios";

class GridComp extends Component{
    state = {
        users :[]      
    }
    loaddata=()=>{
        axios.get("https://reqres.in/api/users?page=2").then((res)=>{
            // console.log(res.data.data);
            this.setState({
                users : res.data.data
            })
        }).catch(err=>console.log(err))
    }
    componentDidMount(){
        this.loaddata();
    }
    render(){
        return <table className="table">
        <thead>
          <tr>
            <th scope="col">sl no</th>
            <th scope="col">photo</th>
            <th scope="col">first name</th>
            <th scope="col">last name</th>
          </tr>
        </thead>
        <tbody>
          {
            this.state.users.map((data,idx)=>{
            return <tr key={data.id}>
                    <td>{idx+1}</td>
                    <td><img width={50} src={data.avatar} alt={data.first_name} /></td>
                    <td>{data.first_name}</td>
                    <td>{data.last_name}</td>
                </tr>
            })
          }
        </tbody>
      </table>
    }
}

export default GridComp