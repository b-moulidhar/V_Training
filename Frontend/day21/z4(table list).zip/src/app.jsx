import { Component } from "react";
import GridComp from "./grid.component";
 
class App extends Component{
    state = {
        users :[]      
    }
    render(){
        return <div>
            <h1>user's list</h1>
             <GridComp/>
        </div>
       
    }
}

export default App;
 
