import { Component } from "react";


class HeroComp extends Component{
    state={
        title : "HeroComp component"    
    }
    render(){
         if(this.props.power<5){
                throw new Error("hero has power less than 5")
         }else{
            return <div>
                <h2>{this.state.title} has power {this.props.power}</h2>
            </div>
         }
    }
}
export default HeroComp;