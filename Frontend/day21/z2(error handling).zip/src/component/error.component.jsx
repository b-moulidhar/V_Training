import { Component } from "react";


class ErrorBoundary extends Component{
    state={
        message : "",
        hasError :false
    }
    // static getDerivedStateFromError(error){
    //     return {
    //         message: error.message,
    //         hasError:true
    //     }
    // }
    componentDidCatch(error){
        // console.log(args.length)
        // console.log(args[0],args[1])
        this.setState({
            message: error.message,
            hasError:true
        })
        
    } 
    render(){
       if(this.state.hasError){
        return <h3>hero not ready {this.state.message}</h3>
       }else{
        return this.props.children
       }
    }
}
export default ErrorBoundary;