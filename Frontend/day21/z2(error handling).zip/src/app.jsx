import { Component } from "react";
import HeroComp from "./component/hero";
import ErrorBoundary from "./component/error.component";


class App extends Component{
    state={
        title : "App component"    
    }
    render(){
        return <div>
        <h1>{ this.state.title }</h1>
        <ErrorBoundary>  <HeroComp power={Math.round( Math.random() * 10)}/> </ErrorBoundary>
        <ErrorBoundary>  <HeroComp power={Math.round( Math.random() * 10)}/> </ErrorBoundary>
        <ErrorBoundary>  <HeroComp power={Math.round( Math.random() * 10)}/> </ErrorBoundary>
        <ErrorBoundary>  <HeroComp power={Math.round( Math.random() * 10)}/> </ErrorBoundary>
        <ErrorBoundary>  <HeroComp power={Math.round( Math.random() * 10)}/> </ErrorBoundary>
       </div>
    }
}
export default App;