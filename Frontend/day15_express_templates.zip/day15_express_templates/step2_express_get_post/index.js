
const express = require("express");
let app = express();
const port = process.env.PORT || 5002;
//for posting
app.use(express.urlencoded({extended:true}))
let herolist = ["ironman", "batman", "thor"]
app.get("/",(req, res)=>{
    res.render("index.ejs",{
        compname : "valtech",
        herolist
    });
});
app.get("/index.pug",(req, res)=>{
    res.render("index.pug",{
        compname : "valtech"
    });
});
app.get("/index.jade",(req, res)=>{
    res.render("index.jade",{
        compname : "valtech"
    });
});
app.post("/",(req,res)=>{
    // console.log(req.body.nhero);
    herolist.push(req.body.nhero);
    res.redirect("/");
    res.end();
})
app.listen(port,"localhost",(err)=>{
    if(!err){
        console.log("running at ",port);
    }else{
        console.log("error ",err);
    }
})