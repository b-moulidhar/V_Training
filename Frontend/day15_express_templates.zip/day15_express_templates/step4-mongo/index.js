const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

let app = express();
app.use(express.json());
 let url = "mongodb+srv://admin:xixz8QFzJuQ8FHC@cluster0.ziyw6gs.mongodb.net/valtchdb?retryWrites=true&w=majority"

let Schema = mongoose.Schema;
let ObjectId = Schema.ObjectId;

var Hero = mongoose.model("Hero",Schema({
    id:ObjectId,
    title : String,
    firstname : String,
    lastname : String
 }));
 mongoose.connect(url).then(()=>{
    console.log("connected");
 }).catch(()=>{
    console.log("error",err);
 });

 app.get("/",(req,res)=>{
    Hero.find().then(dbres=>{

        res.json(dbres);
    })
 })

app.listen(8080,"localhost",(err)=>{

})