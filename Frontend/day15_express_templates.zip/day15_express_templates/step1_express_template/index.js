const express = require("express");
let app = express();
var port = process.env.PORT || 5000;
console.log(port);

// app.set("views","templates"); //in this case views not compulsary
// app.set("view engine","ejs"); //in this case extention is not compulsary
app.get("/",(req,res)=>{
    
    res.render("index.pug",{
        compname : "Valtech",
        message :"welcome to valtech"
    });
    
})

app.get("/about",(req,res)=>{
    
    res.render("about.pug",{
        compname : "Valtech",
        message :"welcome to valtech's about page"
    });
    
})
app.get("/contact",(req,res)=>{
    
    res.render("contact.pug",{
        compname : "Valtech",
        message :"welcome to valtech's contact page"
    });
   
})
app.listen(port,"localhost",(err)=>{
    if(!err){
        console.log(`running at port ,${port}`);

    }else{
        console.log("error ",err);
    }0

});
