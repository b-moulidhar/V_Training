const express = require("express");
let app = express();
var port = process.env.PORT || 5000;
console.log(port);
app.get("/",(req,res)=>{
    
    res.sendFile(__dirname+"/public/index.html");
    
})

app.get("/about",(req,res)=>{
    
    res.sendFile(__dirname+"/public/about.html");
    
})
app.get("/contact",(req,res)=>{
    
    res.sendFile(__dirname+"/public/contact.html");
   
})
app.listen(port,"localhost",(err)=>{
    if(!err){
        console.log(`running at port ,${port}`);

    }else{
        console.log("error ",err);
    }0

});
