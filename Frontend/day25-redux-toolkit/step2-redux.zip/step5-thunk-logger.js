const  axios  = require("axios");
const redux = require("redux");
let logger = require("redux-logger").createLogger;
// const { default: thunk } = require("redux-thunk");
let reduxthunk = require("redux-thunk").default;
let createStore = redux.legacy_createStore;
let applyMiddleware = redux.applyMiddleware;
let compose = redux.compose;


const AXIOS_USERS_REQUEST = "AXIOS_USERS_REQUEST"
const AXIOS_USERS_SUCCESS = "AXIOS_USERS_SUCCESS"
const AXIOS_USERS_ERROR = "AXIOS_USERS_ERROR"

let fetchUsers = ()=>{
    return {
         type : AXIOS_USERS_REQUEST
    }
}
let fetchUsersSuccess = (users)=>{
    return {
         type : AXIOS_USERS_SUCCESS,
         payload : users
    }
}
let fetchUsersError = (err)=>{
    return {
         type : AXIOS_USERS_ERROR,
         payload : err
    }
}

let initialState = {
    loading : false,
    error :'',
    users : []
}

let reducer = (state=initialState,action)=>{
    switch(action.type){
        case AXIOS_USERS_REQUEST : return {
                                            ...state,
                                            loading : true,
                                            error : '',
                                            users : []
                                         }
        case AXIOS_USERS_ERROR : return {
                                            ...state,
                                            loading : false,
                                            error : action.payload,
                                            users : []
                                         }
        case AXIOS_USERS_SUCCESS : return {
                                            ...state,
                                            loading : false,
                                            error : '',
                                            users : action.payload
                                         }
        default : return state
    }
}
let thunkFetchusers = ()=>{
    return function(dispatch){
        dispatch( fetchUsers() );
    }
}
let thunkAjaxusers = ()=>{
    return function(dispatch){
        axios
        .get("https://reqres.in/api/users?page=2")
        .then((res)=>{
            dispatch( fetchUsersSuccess(res.data.data) )
        })
        .catch((err)=>{
            dispatch( fetchUsersError(err) )
        })
    }
}

let store = createStore(reducer,compose(applyMiddleware(reduxthunk,logger())));

// store.subscribe(()=>{
//     console.log(store.getState());
// });

store.dispatch(thunkFetchusers());
store.dispatch(thunkAjaxusers());