import {BrowserRouter,Routes,Route,NavLink} from "react-router-dom"
import AquamanComp from "./component/aquaman.component";
import BatmanComp from "./component/batman.component";
import HomeComp from "./component/home.component";
import NotFoundComp from "./component/notfound.component";
import SupermanComp from "./component/superman.component";
import WonderWomenComp from "./component/wonderwomen.component";
import "./myroute.css"
let App =()=>{
    let activeFun1 = ({isActive})=> isActive ? 'box' : 'plainBox';
    let activeFun2 = ({isActive})=> {
      return {
        width: "200px",
        display: "inline-block",
        backgroundColor: isActive ? "crimson" : "darkorange",
        color:  "papayawhip",
        textAlign: "center",
        padding: "5px",
      }
    };
    return <div>
        <h1>Universe Heroes Component</h1>
        <BrowserRouter>
        <ul>
            <li><NavLink end className={activeFun1} to="/">Home Component</NavLink></li>
            <li><NavLink style={ activeFun2 } to="/batman">Batman Component</NavLink></li>
            <li><NavLink className={({isActive})=> isActive ? 'box':''} to="/" end>Home</NavLink></li>
            <li><NavLink className={({isActive})=> isActive ? 'box':''} to="batman">batman</NavLink></li>
            <li><NavLink className={({isActive})=> isActive ? 'box':''} to="superman">superman</NavLink></li>
            <li><NavLink className={({isActive})=> isActive ? 'box':''} to="aquaman">aquaman</NavLink></li>
            <li><NavLink className={({isActive})=> isActive ? 'box':''} to="wonderwoman">wonderwoman</NavLink></li>
            <li><NavLink className={({isActive})=> isActive ? 'box':''} to="flash">flash</NavLink></li>
            <li><NavLink className={({isActive})=> isActive ? 'box':''} to="cyborg">cyborg</NavLink></li>
            {/* <li><Link to="/">Home</Link></li>
            <li><Link to="batman">batman</Link></li>
            <li><Link to="superman">superman</Link></li>
            <li><Link to="aquaman">aquaman</Link></li>
            <li><Link to="wonderwoman">wonderwoman</Link></li>
            <li><Link to="flash">flash</Link></li>
            <li><Link to="cyborg">cyborg</Link></li> */}
        </ul>
        
        
            <Routes>
                <Route path="" element={<HomeComp/>}/>
                <Route path="batman" element={<BatmanComp/>}/>
                <Route path="aquaman" element={<AquamanComp/>}/>
                <Route path="superman" element={<SupermanComp/>}/>
                <Route path="wonderwoman" element={<WonderWomenComp/>}/>
                <Route path="flash" element={<SupermanComp/>}/>
                <Route path="*" element={<NotFoundComp/>}/>
            </Routes>
        </BrowserRouter>
    </div>
}
export default App;