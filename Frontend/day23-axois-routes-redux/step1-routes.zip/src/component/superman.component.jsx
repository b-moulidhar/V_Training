import { useNavigate } from "react-router-dom";

let SupermanComp =()=>{
        let navBat = useNavigate();
    return <div>
        <h1>Superman Component</h1>
        <button onClick={()=>{navBat("/batman",{replace:true})}}>batman </button>
    </div>
}
export default SupermanComp;