let WonderWomenComp =()=>{
    return <div>
        <h1>WonderWomen
         Component</h1>
    </div>
}
export default WonderWomenComp;