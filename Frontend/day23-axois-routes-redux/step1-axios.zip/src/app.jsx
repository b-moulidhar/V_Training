import Users from "./component/user.component";

let App =()=>{
    return <div>
        <h1>
            welcome to axios universe
        </h1>
        <Users/>
    </div>
}
export default App;