import { useState } from "react"
import { UseEffectComp } from "./component/useEffect";

let App = ()=>{
    let [state,setState] = useState({power:0, version:0, rating:0});
    return <div>
        <h1>welcome to universe 7 | power : {state.power} | version : {state.version} | rating : {state.rating}</h1>
        power <input type="range" onChange={(evt)=>{ setState({...state, power :evt.target.value }) }}/> <br />
        version <input type="range" onChange={(evt)=>{ setState({...state, version : evt.target.value}) }}/> <br />
        rating <input type="range" onChange={(evt)=>{ setState({...state, rating : evt.target.value}) }}/>
        { state.power < 50 ? <UseEffectComp state={state}/>:  <h3>power greater than 50</h3> }
    </div>
}
export default App;