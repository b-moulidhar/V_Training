function errorHandler(err){
    console.log("error",err);
}

module.exports.errorHandler;