import { Component } from "react";
import PropTypes from "prop-types";

class ChildComp extends Component{
    // static defaultProps = {
    //     title:"default title",
    //     power:0,
    //     version:0
    //     }
 static propTypes = {
    title:PropTypes.string.isRequired,
    power:PropTypes.number.isRequired,
    version:PropTypes.number.isRequired
 }
    render(){
        return <div class="container">
                <ol><h1>
                <li>title: {this.props.title}</li> 
                <li>power :{this.props.power}</li>
                <li>version: {this.props.version}</li>
                    </h1>
                </ol>
        </div>
    }
}
// ChildComp.defaultProps = {
//     title:"default title",
//     power:0,
//     version:0
//     }
export default ChildComp;