import { Component,createRef } from "react";


class ChildComp extends Component{
   state={
    title:"default title",
    power:0
   }
   constructor(){
    super();
    this.increasePower = this.increasePower.bind(this);
   }
   increasePower =()=>{
    this.setState({
        power:this.state.power +1
    })
   };

   setPower=(evt)=>{
    this.setState({
        power:evt.target.value
    })
   }
   elm = createRef();

   changePower=()=>{
    this.setState({
        power: this.elm.current.value
    })
   }
    render(){
        return <div class="container">
                <ol><h1>
                <li>title: {this.state.title}</li> 
                <li>power: {this.state.power}</li> 
                <input onInput={this.setPower} type="range"/>

                <input ref={this.elm} type="text" />
                <button onClick={this.changePower}>set power</button>
                

                {/* <button onClick={ this.increasePower    
                }>change power</button>  */}
                {/* for property increasepower */}

                {/* <button onClick={()=>{this.increasePower()    
                }}>change power1</button>  */}
                {/* inline arrow function */}

                {/* <button onClick={ this.increasePower    
                }>change power</button>  */}
                 {/* for constructor */}

                {/* <button onClick={ this.increasePower.bind(this)    
                }>change power</button> */}

                {/* <button onClick={()=>{
                    this.setState({
                        power: this.state.power +1
                    })
                }}>change power1</button> */}
                <button onClick={()=>{
                    this.setState({
                        title:"Changed"
                    })
                }}>change title</button>
                    </h1>
                </ol>
        </div>
    }
}
// ChildComp.defaultProps = {
//     title:"default title",
//     power:0,
//     version:0
//     }
export default ChildComp;