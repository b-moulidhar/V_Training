import { Component } from "react";
import ChildComp from "./child.component";
class App extends Component{
    
    render(){
        return <div>
            <ChildComp title="child1" power={5} ></ChildComp>
            <ChildComp title="child2"  version={2}></ChildComp>
            <ChildComp  power={7} version={3}></ChildComp>
        </div>
    }
}

export default App;