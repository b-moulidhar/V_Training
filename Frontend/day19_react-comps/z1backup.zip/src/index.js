// import { createRoot } from "react-dom";
// import App from "./app.component";

// /* <h1>Welcome home</h1> */
// createRoot(document.getElementById("root")).render(<App/>);

import { Component } from "react";
import {createRoot } from "react-dom";

// var AvengersList = function(){
//     let avengers = ["thor","ironman","batman"]
//     return <ol>{
//             avengers.map(function(val,idx){
//                 return <li key={idx}>{val}</li>
//             })
//     }
//     </ol>
// };
class AvengersList extends Component{
    render(){
        this.avengers = ["thor","ironman","batman","superman"];
    return <ol>{
            this.avengers.map(function(val,idx){
                return <li key={idx}>{val}</li>
            })
    }
    </ol>
}
};
createRoot(document.getElementById("root")).render(<AvengersList/>);
