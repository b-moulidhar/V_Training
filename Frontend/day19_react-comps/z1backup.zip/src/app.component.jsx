// function App(){
//     return <h1>Welcome to universe 7</h1>
// }
// export default App;

import { Component } from "react";
class App extends Component{
    render(){
        return <h1>Welcome to Universe 7</h1>
    }
};
export default App;
