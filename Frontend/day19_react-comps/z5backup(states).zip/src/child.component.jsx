import { Component } from "react";


class ChildComp extends Component{
   state={
    title:"default title"
   }
    render(){
        return <div class="container">
                <ol><h1>
                <li>title: {this.state.title}</li> 
                <button onClick={()=>{
                    this.setState({
                        title:"Changed"
                    })
                }}>change title</button>
                    </h1>
                </ol>
        </div>
    }
}
// ChildComp.defaultProps = {
//     title:"default title",
//     power:0,
//     version:0
//     }
export default ChildComp;