// import { createRoot } from "react-dom";
// import App from "./app.component";

// /* <h1>Welcome home</h1> */
// createRoot(document.getElementById("root")).render(<App/>);

import {createRoot } from "react-dom";
import App from "./app";
createRoot(document.getElementById("root")).render(<App/>);
