import { Component} from "react";


class ChildComp extends Component{
   state={
    title:"default title",
    power:0
   }
   increasePower=()=>{
    this.setState(function(currentState,CurrentProp){
        return {
            power:currentState.power +1
        }
    },function(){
        console.log(this.state.power);
    })
   }
    render(){
        return <div class="container">
               <h1>child comp</h1>
               <h2>power : { this.state.power }</h2>
               <button onClick={this.increasePower}>increase</button>
        </div>
    }
}

export default ChildComp;