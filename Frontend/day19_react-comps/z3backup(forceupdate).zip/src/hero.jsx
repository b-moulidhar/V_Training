import { Component } from "react";
import Hero from "./app";

class App extends Component{
    render(){
        return <div>
                {/* <Hero> Hello World</Hero>
                <Hero> Hello World 2</Hero>
                <Hero> Hello World 3</Hero> */}
                {this.avengers = ["ironman","hulk","thor","spiderman"]}
                {this.justiceLeague = ["batman","scarlet","captain america",]}
                {this.indicHeroes = ["shaktiman","RaOne","G-One","Krish"]}
                <Hero list = {this.avengers} power={6} title="Avenger1"> </Hero>
                <Hero list = {this.justiceLeague} power={7} title="Avenger2"> </Hero>
                <Hero list = {this.indicHeroes} power={8} title="Avenger3"> </Hero>
        </div>
    }
}
export default App;