import { Component } from "react";

class Hero extends Component{
    power=50;
    render(){
        return <div>
            <h2>
               {this.props.title} : {this.props.power}
            </h2>
            <h4>
                power:{this.power}
            </h4>
            <ol>
                {this.props.list.map((val,idx)=>{
                    return <li key={idx}>{ val }</li>
                })}
            </ol>
            {/* <button onClick={()=>{
                this.props.power = this.props.power+1;
            }}>change power</button> */}{/* Read only for Props*/}
            <button onClick={()=>{
                this.power = this.power+1; this.forceUpdate()
            }}>change power</button>  {/* forceUpdate calls the render function implicitely using react*/}
        </div>
    }
}

export default Hero;