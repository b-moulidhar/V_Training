// import { createRoot } from "react-dom";
// import App from "./app.component";

// /* <h1>Welcome home</h1> */
// createRoot(document.getElementById("root")).render(<App/>);

import {createRoot } from "react-dom";
import App from "./components/app";

// var AvengersList = function(){
//     let avengers = ["thor","ironman","batman"]
//     return <ol>{
//             avengers.map(function(val,idx){
//                 return <li key={idx}>{val}</li>
//             })
//     }
//     </ol>
// };

createRoot(document.getElementById("root")).render(<App/>);
