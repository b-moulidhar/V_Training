import { Component } from "react";
import { createRoot } from "react-dom";
import ProductComp from "./product";

class ProductsComp extends Component{
    render(){
        return <div className="container">
                    <div className="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
                    <ProductComp/>
                    <ProductComp/>
                    <ProductComp/>
                    <ProductComp/>
                    <ProductComp/>
                    <ProductComp/>
                    <ProductComp/>
                    <ProductComp/>
                    <ProductComp/>
                    </div>
                </div>
    }
}

export default ProductsComp;