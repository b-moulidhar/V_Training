import { Component } from "react";
import { createRoot } from "react-dom";
import FooterComp from "./footer";
import HeaderComp from "./header";
import MainComp from "./main";
import ProductsComp from "./products";

class App extends Component{
    render(){
        return <div>
                <HeaderComp/>
                <main>
                    <MainComp/>
                    <ProductsComp/>
                </main>
                <FooterComp/>
        </div>
    }
}

export default App;