import { PureComponent } from "react";
import { Component} from "react";


class ChildPureComp extends PureComponent{
   state={
    title:"default title",
    power:0,
    version:0
   }
   increasePower=()=>{
    this.setState({
        power:this.state.power+1
    })
   }
   setVersion=()=>{
    this.setState({
        version:100
    })
   }
    render(){
        return <div class="container">
               <h1>child  pure comp</h1>
               <h2>power : { this.state.power }</h2>
               <h2>version : { this.state.version }</h2>
               <button onClick={this.increasePower}>increase</button>
               <br />
               <button onClick={this.setVersion}>setVersionto100</button>
        </div>
    }
}

export default ChildPureComp;