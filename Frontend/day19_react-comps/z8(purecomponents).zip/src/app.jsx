import { Component } from "react";
import ChildComp from "./child.component";
import ChildPureComp from "./child.pure.component";
class App extends Component{
    
    render(){
        return <div>
            <ChildComp title="child1" power={5} ></ChildComp>
            <ChildComp title="child2"  version={2}></ChildComp>
            <ChildPureComp  power={7} version={3}></ChildPureComp>
        </div>
    }
}

export default App;