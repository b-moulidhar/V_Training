const http = require("http");
const fs = require("fs");

var server = http.createServer((req,res)=>{
    if(req.url == "/favicon.ico"){
        res.write("");
        res.end();
    }else if(req.url == "/"){
        let content = fs.readFileSync("./index.html","utf-8");
        res.writeHead(200,{"Content-Type":"text/html"});
        res.write(content);
        res.end();
    }else{
        fs.readFile("./"+req.url,"utf-8",(error,htmldata)=>{
            if(!error){ 
                res.writeHead(200,{"Content-Type":"text/html"});
                res.write(htmldata);
                res.end();
            }
            else{
                console.log("error",error);
                res.end();
            }
       
        }
        );
    }
})
server.listen(1001,"127.0.0.1",err=>{
    if(err){
        console.log("error",err);
    }
})