const http = require("http");
const fs = require("fs");

let server = http.createServer((req,res)=>{
    if(req.url === "/" || req.url === "/index.html"){
        let content = fs.readFileSync("index.html","utf-8");
        res.writeHead(200,{"Content-Type":"text/html"});
        res.write(content);
        res.end();
    }
    else if(req.url === "/about.html"){
       
            let content = fs.readFileSync("./about.html","utf-8");
            res.writeHead(200,{"Content-Type":"text/html"});
            res.write(content);
            res.end();
    }

    else if(req.url === "/contact.html"){
        
            let content = fs.readFileSync("./contact.html","utf-8");
            res.writeHead(200,{"Content-Type":"text/html"});
            res.write(content);
            res.end();
    }
    else{
        res.writeHead(404,{"Content-Type":"text/html"},(error)=>{
            console.log("404:not found",error);
            res.end();
        });
    }


})
server.listen(2020,"localhost",(err)=>{
   if(err){ console.log("error ",err)};
})