const fetch = require("fetch");
const fs = require("fs");

fetch.fetchUrl("https://www.valtech.com/en-in/",function(err,meta,data){
    if(!err){
        // console.log(data.toString());
        fs.writeFileSync("temp/temp.html",data,"utf-8");

    }else{
        console.log("error",err);
    }
})