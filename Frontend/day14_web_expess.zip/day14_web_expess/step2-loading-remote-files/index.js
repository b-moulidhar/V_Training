const axios = require("axios");
const fs = require("fs");

axios.get("https://www.valtech.com/en-in/").then((content)=>{
    fs.writeFileSync("temp/temp.html",content.data,"utf-8");
}
).catch((err)=>{
    console.log("error ",err);
})