const express = require("express");
const mongoose = require("mongoose");
const session = require("client-sessions");
const bcrypt = require("bcrypt");

let app = express();
app.use(express.urlencoded({extended:true}));
app.use( session({
    cookieName:"valtech",
    secret:"qhrheflwjrflegbkehulghslgf",
    duration: 10*10*1000,
    activeDuration:5*10*100,
    cookie:{
        ephemeral:true
    }
}) )

let Schema = mongoose.Schema;
let ObjectId = Schema.ObjectId;

let User = mongoose.model("User",new Schema({
    id:ObjectId,
    firstname:String,
    lastname:String,
    email:{type:String ,unique:true},
    password:String
}));

let url = "mongodb+srv://admin:xixz8QFzJuQ8FHC@cluster0.ziyw6gs.mongodb.net/valtechdb?retryWrites=true&w=majority"

mongoose.connect(url).then(function(res){
        console.log(" db connected")
}).catch(err=>{
    console.log("error,",err);
});


app.get("/",(req,res)=>{
    res.render("home.pug");
});
app.get("/login",(req,res)=>{
    res.render("login.pug");
});
app.post("/login",(req,res)=>{
    User.findOne({email:req.body.email},function(err,user){
        if(!user){
            res.render("login.pug",{
                error : "no credentials found"
            });
        }else{
            if(bcrypt.compareSync(req.body.password, user.password)){
                req.valtech.user = user
                res.redirect("/profile");
            }else{
                res.render("/login.pug",{
                    error : "invalid user name or password"
                });
            }
        }

    })
});
app.get("/register",(req,res)=>{
    res.render("register.pug");
});
app.post("/register",(req,res)=>{
    var hash = bcrypt.hashSync(req.body.password,bcrypt.genSaltSync(10));
    var user = new User({
    firstname:req.body.firstname,
    lastname:req.body.lastname,
    email:req.body.email,
    password:hash,

    });
    user.save(function(err){
        clientErr = "";
        if(err){
            if(err.code === 11000){
            clientErr = "Email already registered"
        }else{
            clientErr = "Something went wrong";
            res.render("register.pug", {clientErr });
        }
    }else{
        res.redirect("/profile");
        console.log("user registred");
    }
    })
    // res.render("register.pug");
});
app.get("/profile",(req,res)=>{
    if(req.valtech && req.valtech.user){
        User.findOne({email:req.valtech.user.email},function(err,user){
            if(!user){
                req.valtech.reset();
                res.redirect("/login");
            }else{
                res.render("profile.pug");
            }

        })
    }else{
        res.redirect("/login");
    }
});
app.get("/logout",(req,res)=>{
    req.valtech.reset();
    res.redirect("/");
});

app.listen(2626,"localhost",(err)=>{
    if(err){
        console.log("Error",err);
    }else{
        console.log("running on port 2626");
    }
})