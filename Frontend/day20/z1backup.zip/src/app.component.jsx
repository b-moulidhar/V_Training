import { Component } from "react";

class App extends Component{
    state={
        val : false
    }

    valFun = ()=>{
        this.setState({
            val:!this.state.val
        })
    };
//     render(){
//     if(this.state.val){
//         return <div>
//             <label htmlFor="">show terms and condtions</label>
//             <input onChange={this.valFun} type="checkbox" />
//              <fieldset>
//                 <legend>terms and conditions</legend>
//                 <p>
//                     Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dignissimos distinctio voluptates exercitationem omnis dolores. Odit suscipit velit quam laudantium quae obcaecati tempora adipisci? Dignissimos, eos facilis quis quam dolorum maiores.
//                     Lorem ipsum, dolor sit amet consectetur adipisicing elit. In dicta eos recusandae hic odit? Quidem, nemo deleniti? Deserunt, odit, hic eum cum numquam earum architecto quae enim, aperiam ad explicabo?
//                     Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusantium nostrum sint cum ut eum quam aliquam exercitationem architecto rerum aspernatur vero, asperiores cupiditate laudantium impedit cumque possimus molestias tenetur quis.
//                     Lorem ipsum dolor sit amet consectetur adipisicing elit. Sed ratione reprehenderit atque quaerat esse tempora provident doloremque! Praesentium labore unde voluptatum tempore sequi, repellendus odio ea totam blanditiis, quis nesciunt!
//                     Lorem ipsum dolor sit amet consectetur, adipisicing elit. Iusto ut quod, officia assumenda vitae unde molestiae explicabo error rerum. Tempore nobis veritatis necessitatibus adipisci non cumque sapiente modi vero obcaecati?
//                 </p>
//              </fieldset>
//         </div>
//     }else{
//         <div>
//             <label htmlFor="">show terms and condtions</label>
//             <input onChange={this.valFun} type="checkbox" />
//             </div>

//     }
// }

render(){
    
        return <div>
            <label htmlFor="">show terms and condtions</label>
            <input onChange={this.valFun} type="checkbox" />
             {/* {this.state.val ? <fieldset>
                <legend>terms and conditions</legend>
                <p>
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dignissimos distinctio voluptates exercitationem omnis dolores. Odit suscipit velit quam laudantium quae obcaecati tempora adipisci? Dignissimos, eos facilis quis quam dolorum maiores.
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. In dicta eos recusandae hic odit? Quidem, nemo deleniti? Deserunt, odit, hic eum cum numquam earum architecto quae enim, aperiam ad explicabo?
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusantium nostrum sint cum ut eum quam aliquam exercitationem architecto rerum aspernatur vero, asperiores cupiditate laudantium impedit cumque possimus molestias tenetur quis.
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Sed ratione reprehenderit atque quaerat esse tempora provident doloremque! Praesentium labore unde voluptatum tempore sequi, repellendus odio ea totam blanditiis, quis nesciunt!
                    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Iusto ut quod, officia assumenda vitae unde molestiae explicabo error rerum. Tempore nobis veritatis necessitatibus adipisci non cumque sapiente modi vero obcaecati?
                </p>
             </fieldset>:"Hello world"} */}
             {this.state.val && <fieldset>
                <legend>terms and conditions</legend>
                <p>
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dignissimos distinctio voluptates exercitationem omnis dolores. Odit suscipit velit quam laudantium quae obcaecati tempora adipisci? Dignissimos, eos facilis quis quam dolorum maiores.
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. In dicta eos recusandae hic odit? Quidem, nemo deleniti? Deserunt, odit, hic eum cum numquam earum architecto quae enim, aperiam ad explicabo?
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusantium nostrum sint cum ut eum quam aliquam exercitationem architecto rerum aspernatur vero, asperiores cupiditate laudantium impedit cumque possimus molestias tenetur quis.
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Sed ratione reprehenderit atque quaerat esse tempora provident doloremque! Praesentium labore unde voluptatum tempore sequi, repellendus odio ea totam blanditiis, quis nesciunt!
                    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Iusto ut quod, officia assumenda vitae unde molestiae explicabo error rerum. Tempore nobis veritatis necessitatibus adipisci non cumque sapiente modi vero obcaecati?
                </p>
             </fieldset>}
        </div>
    }
}
export default App;