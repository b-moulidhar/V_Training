import {createRoot } from "react-dom";
import App from "./app.component";
createRoot(document.getElementById("root")).render(<App/>);