import { Component } from "react"

let WithPower = (OriginalComp)=>{
    
    return class TempComp extends Component{
        state ={
            power :0,
            version:0,
        }
        increasePower=()=>{
            this.setState({
                power:this.state.power +1
            })
        }
        increaseVersion=()=>{
            this.setState({
                version:this.state.version +1
            })
        }
        render(){
            return <OriginalComp {...this.props} {...this.state} increasePower={this.increasePower} increaseVersion={this.increaseVersion}/>
        }
    }
}

export default WithPower;