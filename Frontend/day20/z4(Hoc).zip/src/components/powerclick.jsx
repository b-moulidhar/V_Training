import { Component } from "react";
import WithPower from "../hoc/withpower";

class PowerClick extends Component{

    render(){
        return <div style={{border :"2px solid", margin: "10px", padding: "5px"}}> 
            <h2 >
            power click <br />
            </h2>
                power : { this.props.power} <br />
                version : {this.props.version}<br/>
                title : {this.props.title} <br />
                city : {this.props.city} <br />
              <button onClick={ this.props.increasePower }>increase Power</button>
              <button onClick={ this.props.increaseVersion }>increase Version</button>
                </div>
    }
};

export default WithPower(PowerClick);