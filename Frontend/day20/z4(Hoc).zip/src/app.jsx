import { Component } from "react";
import PowerClick from "./components/powerclick";
import PowerSlide from "./components/powerslide";

class App extends Component{
    render(){
        return <h1>
            <h1>welcome to Universe 7</h1>
            <PowerClick title="power click title" city="Bengaluru"/>
            <PowerSlide title="power slide title" city="mangaluru"/>
        </h1>
    }
};

export default App;