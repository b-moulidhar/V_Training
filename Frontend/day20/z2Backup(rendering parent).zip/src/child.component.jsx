import React, { Component } from "react";
class ChildComp extends Component{
    elm = React.createRef();

    chTitle=()=>{
        this.setState({
            title:this.elm.current.value
        })
    }

    render(){
        
            return <div>
                        <h2>
                        power from parent : {this.props.power} <br />
                        <input ref={this.elm} type="text" /> <br />
                        <button onClick={()=>this.props.changeTitle(this.elm.current.value)}>change title</button><br />
                        new input on change<input ref={this.elm} type="text" onChange={()=>{this.props.changeTitle(this.elm.current.value)}}/> <br />
                        new input on blur<input ref={this.elm} type="text" onBlur={(evt)=>{this.props.changeTitle(evt.target.value)}}/>
                        {/* <button onClick={this.chTitle}>change title</button> */}
                        </h2>
                    </div>
        }
    }
export default ChildComp;

// import React, { Component } from "react";
 
// class ChildComp extends Component{
//     state = {
//         tempmessage : "temp message"
//     }
//     elm = React.createRef();
//     render(){
//         return <div>
//                     <h1>Power sent from parent : {this.props.power}</h1>
//                    {/*  <input type="text" onBlur={(evt)=> this.props.changeTitle(evt.target.value) }  /> */}
//                    {/* <input ref={this.elm} type="text" onBlur={()=> this.props.changeTitle(this.elm.current.value) }  /> */}
//                    <input type="text" onBlur={(evt)=> this.setState({ tempmessage : evt.target.value}) }  />
//                    <button onClick={()=> this.props.changeTitle(this.state.tempmessage)}>change parent title</button>
//                </div>
        
//      }
// };
 
// export default ChildComp