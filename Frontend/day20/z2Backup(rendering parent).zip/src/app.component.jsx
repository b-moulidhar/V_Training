import { Component} from "react";
import ChildComp from "./child.component";

class App extends Component{
    state={
        power:0,
        title:"Avengers"
    }

    increasePower = ()=>{
        this.setState({
            power:this.state.power+1
        })
    };
    decreasePower = ()=>{
        this.setState({
            power:this.state.power-1
        })
    };
    changeTitle=(ntitle)=>{
        this.setState({
            // title:"Changed"
            title : ntitle
        })
    }
   


    render(){
        
            return <div>
                       <h1> {this.state.title} <br />
                        power : {this.state.power}</h1>
                        <button onClick={this.increasePower}>increasePower</button>
                        <button onClick={this.decreasePower}>decreasePower</button>
                        <hr />
                        <ChildComp changeTitle = {this.changeTitle} chTitle={this.chTitle} power = {this.state.power}></ChildComp>
                    </div>
        }
    }
export default App;